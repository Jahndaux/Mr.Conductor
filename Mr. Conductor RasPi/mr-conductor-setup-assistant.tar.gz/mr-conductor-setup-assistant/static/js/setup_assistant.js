/**
 * Mr. Conductor Setup Assistant JavaScript
 * Handles all interactive functionality for the setup assistant
 */

class SetupAssistant {
    constructor() {
        this.statusInterval = null;
        this.init();
    }

    init() {
        this.bindEvents();
        this.loadCommands();
        this.startStatusUpdates();
    }

    bindEvents() {
        // Refresh button
        document.getElementById('refreshBtn').addEventListener('click', () => {
            this.refreshStatus();
        });

        // Fix buttons
        document.querySelectorAll('.fix-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const fixType = e.target.getAttribute('data-fix');
                this.applyFix(fixType);
            });
        });

        // Quick action buttons
        document.getElementById('emergencyResetBtn').addEventListener('click', () => {
            this.confirmEmergencyReset();
        });

        document.getElementById('restartServicesBtn').addEventListener('click', () => {
            this.applyFix('restart_services');
        });

        document.getElementById('openMrConductorBtn').addEventListener('click', () => {
            this.openMrConductor();
        });

        // Tab buttons
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.switchTab(e.target.getAttribute('data-tab'));
            });
        });

        // Log tab buttons
        document.querySelectorAll('.log-tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.loadLogs(e.target.getAttribute('data-service'));
                this.setActiveLogTab(e.target);
            });
        });

        // Copy buttons
        document.querySelectorAll('.copy-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.copyToClipboard(e.target.getAttribute('data-target'));
            });
        });

        // Modal buttons
        document.getElementById('successOkBtn').addEventListener('click', () => {
            this.hideModal('successModal');
            this.refreshStatus();
        });

        document.getElementById('errorOkBtn').addEventListener('click', () => {
            this.hideModal('errorModal');
        });

        // Close modals on background click
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.hideModal(modal.id);
                }
            });
        });
    }

    async refreshStatus() {
        try {
            const response = await fetch('/api/status');
            const status = await response.json();
            this.updateStatusDisplay(status);
        } catch (error) {
            console.error('Failed to refresh status:', error);
            this.showError('Failed to refresh status', 'Please check your connection and try again.');
        }
    }

    updateStatusDisplay(status) {
        const statusMap = {
            'hostapd': 'WiFi Hotspot',
            'dnsmasq': 'DHCP Server', 
            'mr_conductor': 'Mr. Conductor Service',
            'wifi_interface': 'WiFi Interface Mode',
            'ip_address': 'IP Address',
            'jam_pi_broadcasting': 'JAM-PI Broadcasting'
        };

        Object.keys(status).forEach(service => {
            const card = document.querySelector(`[data-service="${service}"]`);
            if (card) {
                const isGood = status[service];
                const statusText = card.querySelector('.status-text');
                
                // Remove existing status classes
                card.classList.remove('status-good', 'status-bad', 'status-warning');
                
                if (isGood) {
                    card.classList.add('status-good');
                    statusText.textContent = `✅ ${statusMap[service]} is working correctly`;
                } else {
                    card.classList.add('status-bad');
                    statusText.textContent = `❌ ${statusMap[service]} needs attention`;
                }
            }
        });

        // Update overall system status
        const allGood = Object.values(status).every(s => s);
        if (allGood) {
            this.showSystemHealthy();
        }
    }

    showSystemHealthy() {
        // Add a subtle celebration effect
        document.body.style.background = 'linear-gradient(135deg, #F0FFF0 0%, #E8F4F8 100%)';
        setTimeout(() => {
            document.body.style.background = '';
        }, 3000);
    }

    async applyFix(fixType) {
        this.showProgress(`Applying ${fixType} fix...`, 'Please wait while we resolve the issue.');
        
        try {
            const response = await fetch(`/api/fix/${fixType}`, {
                method: 'POST'
            });
            const result = await response.json();
            
            this.hideModal('progressModal');
            
            if (result.success) {
                this.showSuccess('Fix Applied Successfully!', result.message);
            } else {
                this.showError('Fix Failed', result.message);
            }
        } catch (error) {
            this.hideModal('progressModal');
            this.showError('Network Error', 'Failed to apply fix. Please check your connection.');
        }
    }

    confirmEmergencyReset() {
        const confirmed = confirm(
            '🚨 EMERGENCY RESET 🚨\n\n' +
            'This will stop all services, reset network interfaces, and restart everything.\n\n' +
            'This is the "nuclear option" - use only if nothing else works.\n\n' +
            'Continue with emergency reset?'
        );
        
        if (confirmed) {
            this.applyFix('emergency_reset');
        }
    }

    openMrConductor() {
        window.open('http://192.168.4.1:5000', '_blank');
    }

    switchTab(tabName) {
        // Update tab buttons
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

        // Update tab content
        document.querySelectorAll('.command-block').forEach(block => {
            block.classList.remove('active');
        });
        document.getElementById(`${tabName}-commands`).classList.add('active');
    }

    setActiveLogTab(activeBtn) {
        document.querySelectorAll('.log-tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        activeBtn.classList.add('active');
    }

    async loadLogs(service) {
        const logOutput = document.getElementById('logOutput');
        logOutput.textContent = 'Loading logs...';
        
        try {
            const response = await fetch(`/api/logs/${service}`);
            const result = await response.json();
            logOutput.textContent = result.logs || 'No logs available';
        } catch (error) {
            logOutput.textContent = 'Failed to load logs';
        }
    }

    async loadCommands() {
        try {
            const response = await fetch('/api/commands');
            const commands = await response.json();
            
            document.getElementById('checkCommands').textContent = commands.check_status.join('\n');
            document.getElementById('fixCommands').textContent = commands.fix_wifi.join('\n');
            document.getElementById('emergencyCommands').textContent = commands.emergency_reset.join('\n');
        } catch (error) {
            console.error('Failed to load commands:', error);
        }
    }

    async copyToClipboard(targetId) {
        const element = document.getElementById(targetId);
        const text = element.textContent;
        
        try {
            await navigator.clipboard.writeText(text);
            this.showToast('✅ Commands copied to clipboard!');
        } catch (error) {
            // Fallback for older browsers
            const textArea = document.createElement('textarea');
            textArea.value = text;
            document.body.appendChild(textArea);
            textArea.select();
            document.execCommand('copy');
            document.body.removeChild(textArea);
            this.showToast('✅ Commands copied to clipboard!');
        }
    }

    showProgress(title, message) {
        document.getElementById('progressTitle').textContent = title;
        document.getElementById('progressMessage').textContent = message;
        this.showModal('progressModal');
    }

    showSuccess(title, message) {
        document.getElementById('successTitle').textContent = title;
        document.getElementById('successMessage').textContent = message;
        this.showModal('successModal');
    }

    showError(title, message) {
        document.getElementById('errorTitle').textContent = title;
        document.getElementById('errorMessage').textContent = message;
        this.showModal('errorModal');
    }

    showModal(modalId) {
        document.getElementById(modalId).style.display = 'block';
    }

    hideModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
    }

    showToast(message) {
        // Create toast notification
        const toast = document.createElement('div');
        toast.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--success-green);
            color: white;
            padding: 15px 25px;
            border-radius: 8px;
            font-weight: 600;
            z-index: 10000;
            animation: slideInRight 0.3s ease;
        `;
        toast.textContent = message;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => {
                document.body.removeChild(toast);
            }, 300);
        }, 3000);
    }

    startStatusUpdates() {
        // Initial status check
        this.refreshStatus();
        
        // Auto-refresh every 10 seconds
        this.statusInterval = setInterval(() => {
            this.refreshStatus();
        }, 10000);
    }

    stopStatusUpdates() {
        if (this.statusInterval) {
            clearInterval(this.statusInterval);
            this.statusInterval = null;
        }
    }
}

// Add CSS animations for toast
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes slideOutRight {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
`;
document.head.appendChild(style);

// Initialize the setup assistant when the page loads
document.addEventListener('DOMContentLoaded', () => {
    window.setupAssistant = new SetupAssistant();
    console.log('🎵 Mr. Conductor Setup Assistant initialized!');
});

// Handle page visibility changes
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        window.setupAssistant.stopStatusUpdates();
    } else {
        window.setupAssistant.startStatusUpdates();
    }
});

