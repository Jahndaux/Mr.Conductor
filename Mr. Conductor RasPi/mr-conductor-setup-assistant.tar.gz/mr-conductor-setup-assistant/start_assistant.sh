#!/bin/bash

# Mr. Conductor Setup Assistant Startup Script
# This script starts the web-based setup assistant

echo "🎵 Starting Mr. Conductor Setup Assistant..."
echo ""
echo "📱 The setup assistant will be available at:"
echo "   http://192.168.4.1:8080"
echo "   http://localhost:8080"
echo ""
echo "🔧 Features:"
echo "   ✅ Visual system diagnostics"
echo "   ✅ One-click fixes"
echo "   ✅ Copy-paste commands"
echo "   ✅ Real-time service monitoring"
echo ""
echo "Press Ctrl+C to stop the assistant"
echo ""

# Change to the web directory
cd "$(dirname "$0")/web"

# Start the Flask application
python3 setup_assistant.py

