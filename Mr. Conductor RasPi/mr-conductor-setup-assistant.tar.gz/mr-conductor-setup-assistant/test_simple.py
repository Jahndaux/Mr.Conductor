#!/usr/bin/env python3
"""
Simple test Flask app to verify the setup assistant works
"""

from flask import Flask, render_template, jsonify
from flask_cors import CORS

app = Flask(__name__, 
           template_folder='../templates',
           static_folder='../static')
CORS(app)

@app.route('/')
def index():
    """Main setup assistant page"""
    return render_template('setup_assistant.html')

@app.route('/api/status')
def get_status():
    """Get current system status"""
    # Mock status for testing
    status = {
        'hostapd': True,
        'dnsmasq': False,
        'mr_conductor': True,
        'wifi_interface': False,
        'ip_address': True,
        'jam_pi_broadcasting': False
    }
    return jsonify(status)

@app.route('/api/commands')
def get_commands():
    """Get copy-paste commands for manual execution"""
    commands = {
        'check_status': [
            'sudo systemctl status hostapd',
            'sudo systemctl status dnsmasq',
            'sudo systemctl status mr-conductor'
        ],
        'fix_wifi': [
            'sudo systemctl stop hostapd',
            'sudo iw dev wlan0 set type __ap',
            'sudo systemctl start hostapd'
        ],
        'emergency_reset': [
            'sudo systemctl stop hostapd dnsmasq mr-conductor',
            'sudo rfkill unblock wifi',
            'sudo ip addr add 192.168.4.1/24 dev wlan0',
            'sudo iw dev wlan0 set type __ap',
            'sudo systemctl start hostapd dnsmasq mr-conductor'
        ]
    }
    return jsonify(commands)

if __name__ == '__main__':
    print("🎵 Mr. Conductor Setup Assistant (Test Version)")
    print("📱 Open browser to: http://localhost:8080")
    app.run(host='0.0.0.0', port=8080, debug=False)

