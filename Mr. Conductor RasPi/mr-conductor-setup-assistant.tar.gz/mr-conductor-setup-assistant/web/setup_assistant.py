#!/usr/bin/env python3
"""
Mr. Conductor Setup Assistant
A web-based, point-and-click interface for diagnosing and fixing Mr. Conductor setup issues.
"""

import os
import subprocess
import json
import time
from flask import Flask, render_template, jsonify, request
from flask_cors import CORS

app = Flask(__name__, 
           template_folder='../templates',
           static_folder='../static')
CORS(app)

class SystemDiagnostics:
    """System diagnostic and auto-fix functionality"""
    
    def __init__(self):
        self.status = {
            'hostapd': False,
            'dnsmasq': False,
            'mr_conductor': False,
            'wifi_interface': False,
            'ip_address': False,
            'jam_pi_broadcasting': False
        }
    
    def check_service_status(self, service_name):
        """Check if a systemd service is running"""
        try:
            result = subprocess.run(['systemctl', 'is-active', service_name], 
                                  capture_output=True, text=True)
            return result.stdout.strip() == 'active'
        except:
            return False
    
    def check_wifi_interface(self):
        """Check if wlan0 is in AP mode"""
        try:
            result = subprocess.run(['iw', 'dev', 'wlan0', 'info'], 
                                  capture_output=True, text=True)
            return 'type AP' in result.stdout
        except:
            return False
    
    def check_ip_address(self):
        """Check if wlan0 has the correct IP address"""
        try:
            result = subprocess.run(['ip', 'addr', 'show', 'wlan0'], 
                                  capture_output=True, text=True)
            return '192.168.4.1/24' in result.stdout
        except:
            return False
    
    def check_jam_pi_broadcasting(self):
        """Check if JAM-PI network is visible"""
        try:
            result = subprocess.run(['iwlist', 'wlan0', 'scan'], 
                                  capture_output=True, text=True)
            return 'JAM-PI' in result.stdout
        except:
            return False
    
    def run_full_diagnostics(self):
        """Run complete system diagnostics"""
        self.status['hostapd'] = self.check_service_status('hostapd')
        self.status['dnsmasq'] = self.check_service_status('dnsmasq')
        self.status['mr_conductor'] = self.check_service_status('mr-conductor')
        self.status['wifi_interface'] = self.check_wifi_interface()
        self.status['ip_address'] = self.check_ip_address()
        self.status['jam_pi_broadcasting'] = self.check_jam_pi_broadcasting()
        return self.status
    
    def fix_wifi_interface(self):
        """Fix WiFi interface to AP mode"""
        commands = [
            ['systemctl', 'stop', 'hostapd'],
            ['iw', 'dev', 'wlan0', 'set', 'type', '__ap'],
            ['systemctl', 'start', 'hostapd']
        ]
        return self.run_commands(commands)
    
    def fix_ip_address(self):
        """Fix wlan0 IP address"""
        commands = [
            ['ip', 'addr', 'flush', 'dev', 'wlan0'],
            ['ip', 'addr', 'add', '192.168.4.1/24', 'dev', 'wlan0']
        ]
        return self.run_commands(commands)
    
    def fix_dnsmasq_config(self):
        """Create clean dnsmasq configuration"""
        config_content = """interface=wlan0
dhcp-range=192.168.4.2,192.168.4.20,255.255.255.0,24h
no-resolv
no-poll
bind-interfaces
"""
        try:
            with open('/etc/dnsmasq.conf', 'w') as f:
                f.write(config_content)
            subprocess.run(['systemctl', 'restart', 'dnsmasq'], check=True)
            return True
        except:
            return False
    
    def restart_all_services(self):
        """Restart all Mr. Conductor services"""
        commands = [
            ['systemctl', 'restart', 'hostapd'],
            ['systemctl', 'restart', 'dnsmasq'],
            ['systemctl', 'restart', 'mr-conductor']
        ]
        return self.run_commands(commands)
    
    def emergency_reset(self):
        """Emergency reset - nuclear option"""
        commands = [
            ['systemctl', 'stop', 'hostapd', 'dnsmasq', 'mr-conductor'],
            ['rfkill', 'unblock', 'wifi'],
            ['ip', 'addr', 'flush', 'dev', 'wlan0'],
            ['ip', 'addr', 'add', '192.168.4.1/24', 'dev', 'wlan0'],
            ['iw', 'dev', 'wlan0', 'set', 'type', '__ap'],
            ['systemctl', 'start', 'hostapd'],
            ['systemctl', 'start', 'dnsmasq'],
            ['systemctl', 'start', 'mr-conductor']
        ]
        return self.run_commands(commands)
    
    def run_commands(self, commands):
        """Run a list of commands with sudo"""
        try:
            for cmd in commands:
                subprocess.run(['sudo'] + cmd, check=True, 
                             capture_output=True, text=True)
            return True
        except subprocess.CalledProcessError as e:
            return False
    
    def get_service_logs(self, service_name, lines=20):
        """Get recent logs for a service"""
        try:
            result = subprocess.run(['journalctl', '-u', service_name, '-n', str(lines)], 
                                  capture_output=True, text=True)
            return result.stdout
        except:
            return "Unable to retrieve logs"

# Global diagnostics instance
diagnostics = SystemDiagnostics()

@app.route('/')
def index():
    """Main setup assistant page"""
    return render_template('setup_assistant.html')

@app.route('/api/status')
def get_status():
    """Get current system status"""
    status = diagnostics.run_full_diagnostics()
    return jsonify(status)

@app.route('/api/fix/<fix_type>', methods=['POST'])
def apply_fix(fix_type):
    """Apply a specific fix"""
    success = False
    message = ""
    
    if fix_type == 'wifi_interface':
        success = diagnostics.fix_wifi_interface()
        message = "WiFi interface fixed" if success else "Failed to fix WiFi interface"
    
    elif fix_type == 'ip_address':
        success = diagnostics.fix_ip_address()
        message = "IP address fixed" if success else "Failed to fix IP address"
    
    elif fix_type == 'dnsmasq':
        success = diagnostics.fix_dnsmasq_config()
        message = "dnsmasq configuration fixed" if success else "Failed to fix dnsmasq"
    
    elif fix_type == 'restart_services':
        success = diagnostics.restart_all_services()
        message = "Services restarted" if success else "Failed to restart services"
    
    elif fix_type == 'emergency_reset':
        success = diagnostics.emergency_reset()
        message = "Emergency reset completed" if success else "Emergency reset failed"
    
    return jsonify({
        'success': success,
        'message': message
    })

@app.route('/api/logs/<service>')
def get_logs(service):
    """Get logs for a specific service"""
    logs = diagnostics.get_service_logs(service)
    return jsonify({'logs': logs})

@app.route('/api/commands')
def get_commands():
    """Get copy-paste commands for manual execution"""
    commands = {
        'check_status': [
            'sudo systemctl status hostapd',
            'sudo systemctl status dnsmasq',
            'sudo systemctl status mr-conductor'
        ],
        'fix_wifi': [
            'sudo systemctl stop hostapd',
            'sudo iw dev wlan0 set type __ap',
            'sudo systemctl start hostapd'
        ],
        'fix_ip': [
            'sudo ip addr flush dev wlan0',
            'sudo ip addr add 192.168.4.1/24 dev wlan0'
        ],
        'emergency_reset': [
            'sudo systemctl stop hostapd dnsmasq mr-conductor',
            'sudo rfkill unblock wifi',
            'sudo ip addr add 192.168.4.1/24 dev wlan0',
            'sudo iw dev wlan0 set type __ap',
            'sudo systemctl start hostapd dnsmasq mr-conductor'
        ]
    }
    return jsonify(commands)

if __name__ == '__main__':
    print("🎵 Mr. Conductor Setup Assistant Starting...")
    print("📱 Open browser to: http://192.168.4.1:8080")
    print("🔧 Point-and-click diagnostics and fixes!")
    try:
        app.run(host='0.0.0.0', port=8080, debug=False)
    except Exception as e:
        print(f"Error starting Flask app: {e}")

