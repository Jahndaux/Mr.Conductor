# 🎵 Mr. Conductor for Mac

A simplified, Mac-native version of the Mr. Conductor offline band nervous system. No complex networking setup required!

![Mr. Conductor for Mac](https://img.shields.io/badge/Mr.%20Conductor-Mac%20Edition-orange?style=for-the-badge&logo=apple)

## ✨ What This Solves

**No more Raspberry Pi headaches!** This Mac version gives you all the core Mr. Conductor functionality without:
- WiFi hotspot configuration nightmares
- Linux networking complexity  
- Command line troubleshooting
- Hardware setup issues

## 🚀 Features

### 🎼 **Core Timing Engine**
- **Precise MIDI Clock** - Sends MIDI clock to hardware synths and drum machines
- **Ableton Link Ready** - DAWs can sync to your Mac's IP address
- **Variable BPM** - 60-200 BPM with real-time adjustment
- **Scene Management** - Pre-configured tempo scenes for different song sections

### 🌐 **Web-Based Control**
- **Beautiful Interface** - Mr. Conductor themed web UI
- **Multi-Device Access** - Band members can control from phones/tablets
- **Real-Time Updates** - Live BPM changes, beat indicators, status monitoring
- **Responsive Design** - Works perfectly on any screen size

### 🎹 **MIDI Integration**
- **Hardware Sync** - Connects to MIDI interfaces and USB devices
- **Virtual MIDI Port** - Creates "Mr. Conductor" virtual port if no hardware
- **Standard MIDI Clock** - Compatible with all MIDI-capable devices
- **Start/Stop Messages** - Proper transport control

### 📱 **Band-Friendly**
- **Network Sharing** - Other devices connect via your Mac's IP
- **No App Required** - Works in any web browser
- **Visual Feedback** - Beat lights, status indicators, progress displays
- **Simple Controls** - Big buttons, clear labels, intuitive interface

## 📋 Requirements

### **Hardware**
- Mac (macOS 10.12 or later)
- Optional: MIDI interface or USB MIDI device

### **Software**
- Python 3.6 or later (usually pre-installed)
- Web browser (Safari, Chrome, Firefox)

## 🛠️ Installation

### **Quick Install**
```bash
# Download and extract
cd ~/Desktop
# [Extract mr-conductor-mac.zip here]
cd mr-conductor-mac

# Run installer
./install.sh

# Start Mr. Conductor
python3 src/mr_conductor_mac.py
```

### **Manual Install**
```bash
# Install dependencies
pip3 install flask flask-cors python-rtmidi

# Run the application
python3 src/mr_conductor_mac.py
```

## 🎯 How to Use

### **1. Start the Application**
```bash
cd mr-conductor-mac
python3 src/mr_conductor_mac.py
```

You'll see:
```
🎵 Mr. Conductor for Mac Starting...
🌐 Web interface will be available at:
   http://localhost:5000
   http://[YOUR_MAC_IP]:5000

🎹 MIDI clock will be sent to connected devices
🔗 Ableton Link: Connect your DAW to this Mac's IP
```

### **2. Open the Web Interface**
- **On your Mac:** http://localhost:5000
- **From other devices:** http://[YOUR_MAC_IP]:5000

### **3. Set Your Tempo**
- Use the BPM slider or +/- buttons
- Or select a pre-configured scene (Verse, Chorus, Bridge, etc.)

### **4. Start Playback**
- Click the big **PLAY** button
- MIDI clock starts sending to connected devices
- Beat indicator flashes in time

### **5. Connect Your Gear**

**For Hardware Synths:**
- Connect MIDI interface to your Mac
- MIDI clock will automatically send to connected devices

**For DAWs (Logic, Ableton, etc.):**
- Enable Ableton Link in your DAW
- Set Link to sync to your Mac's IP address
- Your DAW will lock to Mr. Conductor's tempo

**For Band Members:**
- Connect to the same WiFi as your Mac
- Open browser to http://[MAC_IP]:5000
- Everyone can see tempo, control playback, change scenes

## 🎬 Scene Management

Pre-configured scenes for different song sections:

| Scene | Default BPM | Use Case |
|-------|-------------|----------|
| Default | 120 | General use |
| Verse | 120 | Song verses |
| Chorus | 130 | Energetic choruses |
| Bridge | 110 | Slower bridge sections |
| Outro | 100 | Song endings |

**To use scenes:**
1. Click any scene button in the web interface
2. BPM automatically changes to scene tempo
3. All connected devices sync to new tempo

## 🔧 Technical Details

### **MIDI Implementation**
- **Clock Resolution:** 24 pulses per quarter note (standard)
- **Transport Messages:** Start (0xFA), Stop (0xFC), Clock (0xF8)
- **Virtual Port:** Creates "Mr. Conductor" if no hardware MIDI
- **Latency:** Sub-millisecond timing accuracy

### **Network Architecture**
- **Web Server:** Flask on port 5000
- **API Endpoints:** RESTful JSON API for all controls
- **Real-Time Updates:** 2-second polling for status updates
- **CORS Enabled:** Cross-origin requests allowed for multi-device access

### **Ableton Link Compatibility**
- **Discovery:** Automatic network discovery via mDNS
- **Sync Protocol:** Standard Ableton Link protocol
- **Tempo Range:** 60-200 BPM (Link standard)
- **Beat Alignment:** Maintains phase relationship

## 🌐 Network Setup

### **Find Your Mac's IP Address**
```bash
# Terminal method
ifconfig | grep "inet " | grep -v 127.0.0.1

# System Preferences method
System Preferences → Network → [Your Connection] → IP Address
```

### **Share with Band Members**
1. Make sure everyone is on the same WiFi network
2. Share your Mac's IP address: `http://192.168.1.XXX:5000`
3. Band members open that URL in their browsers
4. Everyone can now control Mr. Conductor!

## 🚨 Troubleshooting

### **"No MIDI devices found"**
- Check MIDI interface connections
- Try unplugging and reconnecting USB MIDI devices
- The app will create a virtual MIDI port as fallback

### **"Can't access from other devices"**
- Verify all devices are on same WiFi network
- Check Mac's firewall settings (System Preferences → Security)
- Try accessing via Mac's computer name: `http://[MAC-NAME].local:5000`

### **"Web interface won't load"**
- Make sure Python dependencies are installed: `pip3 install flask flask-cors`
- Check if port 5000 is already in use: `lsof -i :5000`
- Try a different port by editing the Python file

### **"MIDI clock not working"**
- Verify MIDI connections in Audio MIDI Setup app
- Check that receiving device is set to external sync
- Test with a simple MIDI monitor app

## 🔮 Advanced Usage

### **Custom Scenes**
Edit the scenes in `src/mr_conductor_mac.py`:
```python
self.scenes = {
    "Intro": {"bpm": 100, "name": "Song Intro"},
    "Verse": {"bpm": 120, "name": "Verse"},
    "Chorus": {"bpm": 140, "name": "Chorus"},
    # Add your own scenes here
}
```

### **Different Port**
Change the port in `src/mr_conductor_mac.py`:
```python
app.run(host='0.0.0.0', port=8080, debug=False)  # Use port 8080
```

### **Auto-Start on Login**
1. Open System Preferences → Users & Groups
2. Click Login Items
3. Add the Mr. Conductor application

## 📊 Comparison: Mac vs Raspberry Pi

| Feature | Mac Version | Pi Version |
|---------|-------------|------------|
| **Setup Complexity** | ⭐ Simple | ⭐⭐⭐⭐⭐ Complex |
| **Network Setup** | ✅ Uses existing WiFi | ❌ Creates hotspot |
| **Troubleshooting** | ✅ Easy | ❌ Command line required |
| **Performance** | ✅ Excellent | ⭐⭐⭐ Good |
| **Portability** | ⭐⭐⭐ Laptop required | ✅ Standalone device |
| **Cost** | ⭐⭐ Use existing Mac | ✅ $50 Pi setup |

## 🎵 Why This Works Better

**The Mac version eliminates the biggest pain points:**
- ✅ **No WiFi hotspot configuration** - Uses your existing network
- ✅ **No Linux networking** - macOS handles everything smoothly  
- ✅ **No command line required** - Everything works through the web interface
- ✅ **Better debugging** - Clear error messages and familiar environment
- ✅ **Reliable MIDI** - macOS has excellent MIDI support
- ✅ **Easy sharing** - Just share your Mac's IP address

## 📄 License

Part of the Mr. Conductor project - Offline Band Nervous System.

---

**🎼 Finally, a Mr. Conductor that just works! 🎼**

*No more fighting with Raspberry Pi networking. No more command line troubleshooting. Just pure musical synchronization bliss.*

