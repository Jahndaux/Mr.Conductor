#!/bin/bash

# Mr. Conductor for Mac - Installation Script
echo "🎵 Installing Mr. Conductor for Mac..."
echo ""

# Check if Python 3 is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is required but not installed."
    echo "Please install Python 3 from https://python.org"
    exit 1
fi

echo "✅ Python 3 found: $(python3 --version)"

# Check if pip is installed
if ! command -v pip3 &> /dev/null; then
    echo "❌ pip3 is required but not installed."
    echo "Please install pip3"
    exit 1
fi

echo "✅ pip3 found"

# Install Python dependencies
echo ""
echo "📦 Installing Python dependencies..."
pip3 install -r requirements.txt

if [ $? -eq 0 ]; then
    echo "✅ Dependencies installed successfully"
else
    echo "❌ Failed to install dependencies"
    echo "You may need to run: pip3 install flask flask-cors python-rtmidi"
    exit 1
fi

# Make the main script executable
chmod +x src/mr_conductor_mac.py

echo ""
echo "🎉 Installation complete!"
echo ""
echo "🚀 To start Mr. Conductor:"
echo "   cd $(pwd)"
echo "   python3 src/mr_conductor_mac.py"
echo ""
echo "🌐 Then open your browser to:"
echo "   http://localhost:5000"
echo ""
echo "🎵 Happy conducting!"

