/**
 * Mr. Conductor for Mac - JavaScript Interface
 * Handles all interactive functionality and real-time updates
 */

class MrConductorMac {
    constructor() {
        this.isPlaying = false;
        this.currentBPM = 120;
        this.currentScene = 'Default';
        this.scenes = {};
        this.statusInterval = null;
        this.beatInterval = null;
        
        this.init();
    }

    init() {
        this.bindEvents();
        this.loadScenes();
        this.startStatusUpdates();
        this.updateNetworkUrl();
    }

    bindEvents() {
        // BPM slider
        const bpmSlider = document.getElementById('bpmSlider');
        if (bpmSlider) {
            bpmSlider.addEventListener('input', (e) => {
                this.setBPM(e.target.value);
            });
        }

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.code === 'Space') {
                e.preventDefault();
                this.togglePlayback();
            }
        });
    }

    async makeRequest(url, options = {}) {
        try {
            const response = await fetch(url, {
                headers: {
                    'Content-Type': 'application/json',
                },
                ...options
            });
            return await response.json();
        } catch (error) {
            console.error('Request failed:', error);
            this.updateConnectionStatus(false);
            return null;
        }
    }

    async refreshStatus() {
        const status = await this.makeRequest('/api/status');
        if (status) {
            this.updateConnectionStatus(true);
            this.updateStatusDisplay(status);
        }
    }

    updateConnectionStatus(connected) {
        const indicator = document.getElementById('connectionStatus');
        const text = document.getElementById('connectionText');
        
        if (connected) {
            indicator.classList.remove('disconnected');
            text.textContent = 'Connected';
        } else {
            indicator.classList.add('disconnected');
            text.textContent = 'Disconnected';
        }
    }

    updateStatusDisplay(status) {
        // Update BPM display
        this.currentBPM = status.bpm;
        document.getElementById('bpmValue').textContent = Math.round(status.bpm);
        document.getElementById('bpmSlider').value = status.bpm;

        // Update playback state
        this.isPlaying = status.is_playing;
        this.updatePlayButton();

        // Update beat count
        document.getElementById('beatCount').textContent = `Beat: ${status.beat_count}`;

        // Update system status
        document.getElementById('midiStatus').textContent = 
            status.midi_available ? 'Connected' : 'Not Available';
        
        document.getElementById('deviceCount').textContent = 
            `${status.connected_devices} devices`;

        // Update uptime
        const uptime = this.formatUptime(status.uptime);
        document.getElementById('uptime').textContent = uptime;

        // Update current scene
        this.currentScene = status.current_scene;
        this.updateSceneButtons();
    }

    updatePlayButton() {
        const playBtn = document.getElementById('playBtn');
        const icon = playBtn.querySelector('.btn-icon');
        const text = playBtn.querySelector('.btn-text');

        if (this.isPlaying) {
            playBtn.classList.add('active');
            icon.textContent = '⏸️';
            text.textContent = 'PAUSE';
            this.startBeatAnimation();
        } else {
            playBtn.classList.remove('active');
            icon.textContent = '▶️';
            text.textContent = 'PLAY';
            this.stopBeatAnimation();
        }
    }

    startBeatAnimation() {
        if (this.beatInterval) {
            clearInterval(this.beatInterval);
        }

        const beatLight = document.getElementById('beatLight');
        const beatInterval = 60000 / this.currentBPM; // milliseconds per beat

        this.beatInterval = setInterval(() => {
            beatLight.classList.add('active');
            setTimeout(() => {
                beatLight.classList.remove('active');
            }, 100);
        }, beatInterval);
    }

    stopBeatAnimation() {
        if (this.beatInterval) {
            clearInterval(this.beatInterval);
            this.beatInterval = null;
        }
        document.getElementById('beatLight').classList.remove('active');
    }

    async togglePlayback() {
        if (this.isPlaying) {
            await this.stopPlayback();
        } else {
            await this.playPlayback();
        }
    }

    async playPlayback() {
        const result = await this.makeRequest('/api/play', { method: 'POST' });
        if (result) {
            this.isPlaying = true;
            this.updatePlayButton();
        }
    }

    async stopPlayback() {
        const result = await this.makeRequest('/api/stop', { method: 'POST' });
        if (result) {
            this.isPlaying = false;
            this.updatePlayButton();
        }
    }

    async setBPM(bpm) {
        const result = await this.makeRequest('/api/bpm', {
            method: 'POST',
            body: JSON.stringify({ bpm: parseFloat(bpm) })
        });
        
        if (result) {
            this.currentBPM = result.bpm;
            document.getElementById('bpmValue').textContent = Math.round(result.bpm);
            
            // Update beat animation if playing
            if (this.isPlaying) {
                this.startBeatAnimation();
            }
        }
    }

    adjustBPM(delta) {
        const newBPM = Math.max(60, Math.min(200, this.currentBPM + delta));
        this.setBPM(newBPM);
        document.getElementById('bpmSlider').value = newBPM;
    }

    async loadScenes() {
        const scenes = await this.makeRequest('/api/scenes');
        if (scenes) {
            this.scenes = scenes;
            this.renderScenes();
        }
    }

    renderScenes() {
        const sceneGrid = document.getElementById('sceneGrid');
        sceneGrid.innerHTML = '';

        Object.keys(this.scenes).forEach(sceneName => {
            const scene = this.scenes[sceneName];
            const sceneBtn = document.createElement('div');
            sceneBtn.className = 'scene-btn';
            sceneBtn.onclick = () => this.setScene(sceneName);
            
            sceneBtn.innerHTML = `
                <div class="scene-name">${scene.name}</div>
                <div class="scene-bpm">${scene.bpm} BPM</div>
            `;
            
            sceneGrid.appendChild(sceneBtn);
        });

        this.updateSceneButtons();
    }

    updateSceneButtons() {
        document.querySelectorAll('.scene-btn').forEach((btn, index) => {
            const sceneName = Object.keys(this.scenes)[index];
            if (sceneName === this.currentScene) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });
    }

    async setScene(sceneName) {
        const result = await this.makeRequest('/api/scene', {
            method: 'POST',
            body: JSON.stringify({ scene: sceneName })
        });
        
        if (result) {
            this.currentScene = result.scene;
            this.currentBPM = result.bpm;
            
            // Update UI
            document.getElementById('bpmValue').textContent = Math.round(result.bpm);
            document.getElementById('bpmSlider').value = result.bpm;
            this.updateSceneButtons();
            
            // Update beat animation if playing
            if (this.isPlaying) {
                this.startBeatAnimation();
            }
        }
    }

    updateNetworkUrl() {
        // Try to get the local IP address (this is approximate)
        const networkUrl = document.getElementById('networkUrl');
        if (networkUrl) {
            // This will show the current hostname, users can replace with actual IP
            networkUrl.textContent = `http://${window.location.hostname}:5000`;
        }
    }

    formatUptime(seconds) {
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = Math.floor(seconds % 60);
        
        return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }

    startStatusUpdates() {
        // Initial status check
        this.refreshStatus();
        
        // Auto-refresh every 2 seconds
        this.statusInterval = setInterval(() => {
            this.refreshStatus();
        }, 2000);
    }

    stopStatusUpdates() {
        if (this.statusInterval) {
            clearInterval(this.statusInterval);
            this.statusInterval = null;
        }
        if (this.beatInterval) {
            clearInterval(this.beatInterval);
            this.beatInterval = null;
        }
    }
}

// Global functions for HTML onclick handlers
function togglePlayback() {
    window.mrConductor.togglePlayback();
}

function stopPlayback() {
    window.mrConductor.stopPlayback();
}

function setBPM(bpm) {
    window.mrConductor.setBPM(bpm);
}

function adjustBPM(delta) {
    window.mrConductor.adjustBPM(delta);
}

// Initialize the application when the page loads
document.addEventListener('DOMContentLoaded', () => {
    window.mrConductor = new MrConductorMac();
    console.log('🎵 Mr. Conductor for Mac initialized!');
});

// Handle page visibility changes
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        window.mrConductor.stopStatusUpdates();
    } else {
        window.mrConductor.startStatusUpdates();
    }
});

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    window.mrConductor.stopStatusUpdates();
});

