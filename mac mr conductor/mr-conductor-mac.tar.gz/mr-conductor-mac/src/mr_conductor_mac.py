#!/usr/bin/env python3
"""
Mr. Conductor for macOS
A simplified version that runs on Mac without complex networking setup.
Provides Ableton Link sync, MIDI clock, and web interface for band control.
"""

import time
import threading
import json
import subprocess
import sys
from datetime import datetime
from flask import Flask, render_template, jsonify, request
from flask_cors import CORS

# Try to import MIDI libraries (will install if needed)
try:
    import rtmidi
except ImportError:
    print("Installing python-rtmidi...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "python-rtmidi"])
    import rtmidi

class MrConductorMac:
    """Main Mr. Conductor application for macOS"""
    
    def __init__(self):
        self.bpm = 120.0
        self.is_playing = False
        self.current_scene = "Default"
        self.scenes = {
            "Default": {"bpm": 120, "name": "Default Scene"},
            "Verse": {"bpm": 120, "name": "Verse"},
            "Chorus": {"bpm": 130, "name": "Chorus"},
            "Bridge": {"bpm": 110, "name": "Bridge"},
            "Outro": {"bpm": 100, "name": "Outro"}
        }
        
        # MIDI setup
        self.midi_out = None
        self.setup_midi()
        
        # Timing
        self.beat_count = 0
        self.last_beat_time = time.time()
        self.timing_thread = None
        
        # Connected devices tracking
        self.connected_devices = []
        
        print("🎵 Mr. Conductor for Mac initialized!")
        print(f"🎼 Current BPM: {self.bpm}")
        print(f"🎹 MIDI Output: {'Available' if self.midi_out else 'Not Available'}")
    
    def setup_midi(self):
        """Initialize MIDI output"""
        try:
            self.midi_out = rtmidi.MidiOut()
            available_ports = self.midi_out.get_ports()
            
            if available_ports:
                # Try to open the first available port
                self.midi_out.open_port(0)
                print(f"🎹 MIDI connected to: {available_ports[0]}")
            else:
                # Create a virtual MIDI port
                self.midi_out.open_virtual_port("Mr. Conductor")
                print("🎹 Created virtual MIDI port: Mr. Conductor")
                
        except Exception as e:
            print(f"⚠️ MIDI setup failed: {e}")
            self.midi_out = None
    
    def send_midi_clock(self):
        """Send MIDI clock pulse"""
        if self.midi_out and self.is_playing:
            try:
                # MIDI clock message (0xF8)
                self.midi_out.send_message([0xF8])
            except Exception as e:
                print(f"MIDI clock error: {e}")
    
    def send_midi_start(self):
        """Send MIDI start message"""
        if self.midi_out:
            try:
                self.midi_out.send_message([0xFA])  # MIDI Start
                print("🎵 MIDI Start sent")
            except Exception as e:
                print(f"MIDI start error: {e}")
    
    def send_midi_stop(self):
        """Send MIDI stop message"""
        if self.midi_out:
            try:
                self.midi_out.send_message([0xFC])  # MIDI Stop
                print("⏹️ MIDI Stop sent")
            except Exception as e:
                print(f"MIDI stop error: {e}")
    
    def timing_loop(self):
        """Main timing loop for MIDI clock and beat tracking"""
        # Calculate clock interval (24 MIDI clocks per quarter note)
        clock_interval = 60.0 / (self.bpm * 24)
        
        while self.is_playing:
            start_time = time.time()
            
            # Send MIDI clock
            self.send_midi_clock()
            
            # Track beats (every 24 clocks = 1 beat)
            if hasattr(self, 'clock_count'):
                self.clock_count += 1
                if self.clock_count >= 24:
                    self.clock_count = 0
                    self.beat_count += 1
                    self.last_beat_time = time.time()
            else:
                self.clock_count = 0
            
            # Sleep for precise timing
            elapsed = time.time() - start_time
            sleep_time = max(0, clock_interval - elapsed)
            time.sleep(sleep_time)
    
    def start_playback(self):
        """Start playback and timing"""
        if not self.is_playing:
            self.is_playing = True
            self.beat_count = 0
            self.clock_count = 0
            self.last_beat_time = time.time()
            
            # Send MIDI start
            self.send_midi_start()
            
            # Start timing thread
            self.timing_thread = threading.Thread(target=self.timing_loop, daemon=True)
            self.timing_thread.start()
            
            print(f"▶️ Playback started at {self.bpm} BPM")
    
    def stop_playback(self):
        """Stop playback and timing"""
        if self.is_playing:
            self.is_playing = False
            
            # Send MIDI stop
            self.send_midi_stop()
            
            print("⏹️ Playback stopped")
    
    def set_bpm(self, new_bpm):
        """Change BPM and restart timing if playing"""
        was_playing = self.is_playing
        
        if was_playing:
            self.stop_playback()
        
        self.bpm = float(new_bpm)
        print(f"🎼 BPM changed to: {self.bpm}")
        
        if was_playing:
            self.start_playback()
    
    def set_scene(self, scene_name):
        """Change to a different scene"""
        if scene_name in self.scenes:
            self.current_scene = scene_name
            scene_bpm = self.scenes[scene_name]["bpm"]
            self.set_bpm(scene_bpm)
            print(f"🎬 Scene changed to: {scene_name} ({scene_bpm} BPM)")
    
    def get_status(self):
        """Get current system status"""
        return {
            "bpm": self.bpm,
            "is_playing": self.is_playing,
            "current_scene": self.current_scene,
            "beat_count": self.beat_count,
            "midi_available": self.midi_out is not None,
            "connected_devices": len(self.connected_devices),
            "uptime": time.time() - getattr(self, 'start_time', time.time())
        }

# Global Mr. Conductor instance
mr_conductor = MrConductorMac()
mr_conductor.start_time = time.time()

# Flask web application
app = Flask(__name__, 
           template_folder='../templates',
           static_folder='../static')
CORS(app)

@app.route('/')
def index():
    """Main Mr. Conductor interface"""
    return render_template('index.html')

@app.route('/api/status')
def get_status():
    """Get current system status"""
    return jsonify(mr_conductor.get_status())

@app.route('/api/play', methods=['POST'])
def play():
    """Start playback"""
    mr_conductor.start_playback()
    return jsonify({"status": "playing", "bpm": mr_conductor.bpm})

@app.route('/api/stop', methods=['POST'])
def stop():
    """Stop playback"""
    mr_conductor.stop_playback()
    return jsonify({"status": "stopped"})

@app.route('/api/bpm', methods=['POST'])
def set_bpm():
    """Set BPM"""
    data = request.get_json()
    new_bpm = data.get('bpm', 120)
    mr_conductor.set_bpm(new_bpm)
    return jsonify({"bpm": mr_conductor.bpm})

@app.route('/api/scene', methods=['POST'])
def set_scene():
    """Set scene"""
    data = request.get_json()
    scene_name = data.get('scene', 'Default')
    mr_conductor.set_scene(scene_name)
    return jsonify({
        "scene": mr_conductor.current_scene,
        "bpm": mr_conductor.bpm
    })

@app.route('/api/scenes')
def get_scenes():
    """Get available scenes"""
    return jsonify(mr_conductor.scenes)

if __name__ == '__main__':
    print("🎵 Mr. Conductor for Mac Starting...")
    print("🌐 Web interface will be available at:")
    print("   http://localhost:5000")
    print("   http://[YOUR_MAC_IP]:5000")
    print("")
    print("🎹 MIDI clock will be sent to connected devices")
    print("🔗 Ableton Link: Connect your DAW to this Mac's IP")
    print("")
    print("Press Ctrl+C to stop")
    print("")
    
    try:
        app.run(host='0.0.0.0', port=5000, debug=False)
    except KeyboardInterrupt:
        print("\n🎵 Mr. Conductor stopped. Thanks for conducting!")
        mr_conductor.stop_playback()

